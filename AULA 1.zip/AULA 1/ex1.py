#1) Criar uma aplicação que receba por digitação o nome e o sobrenome e em seguida realize a exibição da seguinte maneira: sobrenome, nome.

# Solicita o nome e sobrenome do usuário
# A função input pausa o código até o úsuario inserir o valor esperado e o armazena na variável quando inserido.
nome = input("Digite seu nome: ")
sobrenome = input("Agora digite seu sobrenome: ")
# Exibe o nome no formato "nome e sobrenome"
print ("seu nome completo é:", nome, sobrenome)


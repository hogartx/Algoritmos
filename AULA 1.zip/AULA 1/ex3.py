#3) Escrever uma aplicação que receba quatro números inteiros digitados pelo usuário e em seguida calcule e exiba a valor da soma desses números.

# Solicita quatro números inteiros do usuário
num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))
num3 = int(input("Digite o terceiro número: "))
num4 = int(input("Digite o quarto número: "))

# Calcula a soma dos números
soma = num1 + num2 + num3 + num4

# Exibe o resultado da soma
print(f"A soma dos números é: {soma}")
